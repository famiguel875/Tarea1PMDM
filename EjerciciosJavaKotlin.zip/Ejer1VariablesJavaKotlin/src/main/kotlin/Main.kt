/**
 *

Ejercicio 1: Declarar variables en Java y Kotlin

En este ejercicio, compararemos cómo se declaran variables en ambos
lenguajes y las diferencias en cuanto a la inferencia de tipos.

public class Main {
    public static void main(String[] args) {
        int vida = 100;
        String personaje = "Naruto";
        System.out.println("El personaje " + personaje + " tiene " + vida + " puntos de vida.");
    }
}

Explica las diferencias entre el uso de var y val en Kotlin frente a las variables en Java.

*/

fun main(args: Array<String>) {

    // val se utiliza para variable fijas que no se van a modificar y
    // var para variables que puedan ser posteriormente modificadas

    // En este programa utilizamos una variable val para el nombre ya que
    // este no se va a modificar. Y una variable var para la vida ya que esta
    // se podría llegar a modificar con metodos que baje o suba la vida del personaje

    var vida: Int = 100
    val personaje: String = "Naruto"

    println("El personaje $personaje tiene $vida puntos de vida.")
}