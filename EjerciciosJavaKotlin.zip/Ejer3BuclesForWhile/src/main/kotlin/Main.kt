/**
 *

Vamos a practicar con bucles, que en ambos lenguajes se usan mucho, sobre todo
en situaciones como recorrer inventarios o colecciones de objetos.

Compara el uso del bucle for en ambos lenguajes, haciendo hincapié en cómo
Kotlin simplifica la sintaxis.

Java:

public class Main {
    public static void main(String[] args) {
        String[] cofres = {"Espada", "Escudo", "Poción"};

        for (String cofre : cofres) {
            System.out.println("Has encontrado: " + cofre);
        }
    }
}

 */

fun main(args: Array<String>) {

    // A diferencia de de kotlin el Array se declara
    // utilizando un ArrayOf dentro de una variabe

    val cofres = arrayOf("Espada", "Escudo", "Poción")

    // Para iterar sobre un Array utilizamos un iterador dentro del bucle for utilizado in

    for (cofre in cofres) {
        println("Has encontrado: $cofre")
    }
}