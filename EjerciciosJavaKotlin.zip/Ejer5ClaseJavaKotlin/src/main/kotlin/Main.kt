/**
 *

Vamos a ver cómo crear una clase simple para un personaje con atributos como nombre, vida y ataque.
Explica cómo Kotlin simplifica la definición de clases y el constructor frente a Java.

Java:

public class Personaje {
    String nombre;
    int vida;
    int ataque;

    public Personaje(String nombre, int vida, int ataque) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
    }

    public void mostrarInfo() {
        System.out.println("Nombre: " + nombre + ", Vida: " + vida + ", Ataque: " + ataque);
    }

    public static void main(String[] args) {
        Personaje goku = new Personaje("Goku", 100, 50);
        goku.mostrarInfo(); }
    }

 */


// En kotlin la variables ya declaradas en el constructor principal se inicializan
// automaticamente, sin necesidad de constructor secundario.
class Personaje(val nombre: String, var vida: Int, var ataque: Int) {

    fun mostrarInfo() {
        println("Nombre: $nombre, Vida: $vida, Ataque: $ataque")
    }
}

fun main() {
    val goku = Personaje("Goku", 100, 50)
    goku.mostrarInfo()
}