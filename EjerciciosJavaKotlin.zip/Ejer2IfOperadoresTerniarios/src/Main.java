/**
 *

 Vamos a ver cómo traducir el operador ternario en Java a Kotlin, ya que Kotlin no tiene
 un operador ternario explícito.

 Explica cómo funciona la estructura if en Kotlin en comparación con el operador ternario en Java.

 Kotlin:

 fun main() {
    val energia = 80
    val estado = if (energia > 50) "Personaje fuerte" else "Personaje débil"
    println(estado) }

 */

public class Main {
    public static void main(String[] args) {

        int energia = 100;

        // Utilizamos ; para declarar la variable antes de usar los operasores,
        // y para if y else tenemos que usar {} obligatoriamente.

        String estado;

        if (energia > 50) {
            estado = "Personaje fuerte";
        } else {
            estado = "Personaje débil";
        }

        System.out.println(estado);
    }
}