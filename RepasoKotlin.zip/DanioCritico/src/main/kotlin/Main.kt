fun calcularDano(dano: Int): Int {
    return if (dano > 50) {
        println("¡Golpe crítico!")
        dano * 2
    } else {
        dano
    }
}

fun main() {
    val dano = 55
    val resultado = calcularDano(dano)
    println("El daño total es de $resultado")
}