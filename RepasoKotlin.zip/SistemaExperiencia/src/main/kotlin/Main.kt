data class PersonajeExperiencia(var experiencia: Int = 0, var nivel: Int = 1)

fun ganarBatalla(personaje: PersonajeExperiencia) {
    personaje.experiencia += 50
    println("El personaje ha ganado 50 puntos de experiencia. Experiencia actual: ${personaje.experiencia}")

    if (personaje.experiencia >= 200) {
        personaje.nivel++
        personaje.experiencia -= 200
        println("¡El personaje ha subido de nivel! Nivel actual: ${personaje.nivel}")
    }
}

fun main() {
    val personaje = PersonajeExperiencia()

    for (i in 1..5) {
        println("\nBatalla $i:")
        ganarBatalla(personaje)
    }
}
