fun main() {
    val vida: Int = 100

    println("La vida del personaje es $vida")
}