class Nivel {
    fun obtenerNivelPersonaje(): Int {
        println("Ingresa el nivel del personaje:")
        return readlnOrNull()?.toIntOrNull() ?: 0
    }
    fun determinarNivel(nivelPersonaje: Int): String {
        return when {
            nivelPersonaje < 10 -> "Personaje principiante"
            nivelPersonaje in 10..20 -> "Personaje intermedio"
            else -> "Personaje avanzado"
        }
    }
}



fun main() {
    val nivel = Nivel()
    val nivelPersonaje = nivel.obtenerNivelPersonaje()
    val resultado = nivel.determinarNivel(nivelPersonaje)
    println(resultado)
}

