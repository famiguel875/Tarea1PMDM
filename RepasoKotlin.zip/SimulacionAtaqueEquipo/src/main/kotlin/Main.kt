fun ataqueEnEquipo(daños: List<Int>, vidaEnemigo: Int): Int {
    var vidaRestante = vidaEnemigo

    for (dano in daños) {
        vidaRestante -= dano
        println("Un miembro del equipo inflige $dano de daño. Vida del enemigo restante: $vidaRestante")
        if (vidaRestante <= 0) {
            println("El enemigo ha sido derrotado.")
            return 0
        }
    }

    return vidaRestante
}

fun main() {
    val equipoDaños = listOf(30, 40, 20, 60, 50)
    val vidaEnemigo = 500

    val vidaFinal = ataqueEnEquipo(equipoDaños, vidaEnemigo)
    if (vidaFinal > 0) {
        println("El enemigo ha sobrevivido con $vidaFinal de vida.")
    }
}
