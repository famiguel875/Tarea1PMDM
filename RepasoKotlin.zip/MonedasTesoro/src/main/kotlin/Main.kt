fun recogeMonedas() {
    var monedas: Int = 0
    for (num in 1..10) {
        monedas += 5
        println("El número de monedas actual es de $monedas")
    }
}

fun main() {
    recogeMonedas()
}