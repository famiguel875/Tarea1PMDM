class ImprimirMensaje {

    fun imprimirHolaMundo() {
        println("Hola Mundo")
    }

}


fun main() {
    val imprimirMensaje = ImprimirMensaje()

    imprimirMensaje.imprimirHolaMundo()
}