fun main() {

    //Arrays

    val week = arrayOf("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")

    val week2: Array<String> = arrayOf()
    val week3 = arrayOf<String>()
    val week4 = Array(5) { i -> (i+1) * 10} //[10, 20, 30, 40, 50]
    val week5 = IntArray(5) { i -> (i+2) * 10}

    println(week4.size)

    // println(week4.contentToString())

    for (dias in week4.indices) {
        println(week4[dias])
    }

    for ((num, dia) in week4.withIndex()) {
        println("Hoy es el dia $num que cae en $dia")
    }
}