fun main() {

    val diasSemana2 = mutableListOf("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")
    //println(diasSemana2)
    //println(diasSemana2.indices)
    //println(diasSemana2.size)

    if (diasSemana2.size <= 8) {
        println(diasSemana2.maxOrNull())
    }

    diasSemana2.forEach {
        println(it)
    }

    println(diasSemana2[diasSemana2.size-1])
    println(diasSemana2.first())
    println(diasSemana2.last())


    // diasSemana2[7] = "Hola"

    // val ejemplo = diasSemana2.find { it == "v"}
    val ejemplo = diasSemana2.filter {
        it.contains("e")
    }

    println(ejemplo)
}