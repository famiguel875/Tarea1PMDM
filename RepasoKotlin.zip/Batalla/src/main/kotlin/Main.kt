data class Personaje(val nombre: String, var vida: Int, val ataque: Int)

class Batalla {
    private fun ataque(personajeAtacante: Personaje, personajeObjetivo: Personaje) {
        if (personajeObjetivo.vida > 0) {
            personajeObjetivo.vida -= personajeAtacante.ataque
            if (personajeObjetivo.vida <= 0) {
                personajeObjetivo.vida = 0
                println("El personaje ${personajeObjetivo.nombre} atacado ya está muerto")
            }
        } else {
            println("El personaje ${personajeObjetivo.nombre} ya está muerto")
        }
        println("El personaje ${personajeObjetivo.nombre} tiene ${personajeObjetivo.vida} de vida")
    }

    fun combate(personaje1: Personaje, personaje2: Personaje) {
        while (personaje1.vida > 0 && personaje2.vida > 0) {
            ataque(personaje1, personaje2)
            if (personaje2.vida > 0) { // Solo atacamos si sigue con vida
                ataque(personaje2, personaje1)
            }
        }

        when {
            personaje1.vida > 0 -> println("El personaje ${personaje1.nombre} ha ganado")
            personaje2.vida > 0 -> println("El personaje ${personaje2.nombre} ha ganado")
            else -> println("Ambos personajes han muerto")
        }
    }
}

fun main() {
    val personaje1 = Personaje("Joel",100, 20)
    val personaje2 = Personaje("Victor",90, 30)

    val batalla = Batalla()

    batalla.combate(personaje1, personaje2)
}