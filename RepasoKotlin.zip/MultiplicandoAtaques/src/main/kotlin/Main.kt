fun multiplicarAtaques(numeroEntero: Int): Int {
    return numeroEntero * 5
}

fun main() {
    println("El daño total del ataque de "+ multiplicarAtaques(3))
    println("El daño total del ataque de "+ multiplicarAtaques(6))
    println("El daño total del ataque de "+ multiplicarAtaques(9))
}