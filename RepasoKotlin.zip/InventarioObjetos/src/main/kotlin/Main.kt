fun main() {
    val inventario = mutableListOf<String>()

    while (true) {
        println("\nMenú de Inventario:")
        println("1. Añadir objeto")
        println("2. Eliminar objeto")
        println("3. Mostrar inventario")
        println("4. Salir")
        print("Selecciona una opción: ")

        when (readlnOrNull()) {
            "1" -> {
                print("Ingresa el objeto a añadir: ")
                val objeto = readlnOrNull()
                if (!objeto.isNullOrEmpty()) {
                    inventario.add(objeto)
                    println("$objeto añadido al inventario.")
                }
            }
            "2" -> {
                print("Ingresa el objeto a eliminar: ")
                val objeto = readlnOrNull()
                if (inventario.remove(objeto)) {
                    println("$objeto eliminado del inventario.")
                } else {
                    println("$objeto no encontrado en el inventario.")
                }
            }
            "3" -> {
                println("Objetos en el inventario: $inventario")
            }
            "4" -> {
                println("Saliendo del inventario.")
                break
            }
            else -> println("Opción no válida. Intenta de nuevo.")
        }
    }
}
